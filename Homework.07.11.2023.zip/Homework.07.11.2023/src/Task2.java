public class Task2 {
    public static void main(String[] args) {
        String d = new String("I study Basic Java");
        changeString(d);
    }
    public static void changeString (String w) {
        char lastChar = w.charAt(w.length()-1);
        boolean findWord = w.contains("Java");
        String changeLetters = w.replace("a","o");
        String upper = w.toUpperCase();
        String lower = w.toLowerCase();
        String substring = w.substring(w.trim().lastIndexOf(" ")+1);


        System.out.println("Последний символ = " + lastChar);
        System.out.println("Существует ли подстрока 'Java' = " + findWord);
        System.out.println("Замена всех букв 'a' на 'o' = " + changeLetters);
        System.out.println("Строка в верхнем регистре = " + upper);
        System.out.println("Строка в нижнем регистре = " + lower);
        System.out.println("Вырезанная строка 'Java' = " + substring);
    }
}
