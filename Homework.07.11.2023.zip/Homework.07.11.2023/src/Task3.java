public class Task3 {
    public static void main(String[] args) {
        String str = "AAABBCCCCDEEFFFG";
        String cmPress = compressString(str);
        System.out.println(cmPress);
    }

    public static String compressString (String str) {
        if (str == null || str.isEmpty()) {
            return str;
        }
        StringBuilder compressed = new StringBuilder();
        char currentChar = str.charAt(0);
        int count = 0;
        for (int i = 0; i < str.length(); i++) {
            char nextChar = str.charAt(i);
            if (currentChar == nextChar) {
                count++;
            } else {
                compressed.append(currentChar);
                if (count > 1){
                    compressed.append(count);
                }
                currentChar = nextChar;
                count = 1;
            }
        }
        compressed.append(currentChar);
        if (count > 1){
            compressed.append(count);
        }
        return compressed.toString();
    }
}