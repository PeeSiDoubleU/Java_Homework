import java.util.Scanner;

public class Task1 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Введите слово: ");
        String word1 = scan.nextLine();
        System.out.println("Введите второе слово: ");
        String word2 = scan.nextLine();
        int lettersCount = (word1.length());
        int lettersCount2 = (word2.length());
        System.out.println(lettersCount + " = количество букв слова " + word1);
        System.out.println(lettersCount2 + " = количество букв слова " + word2);

        if (lettersCount % 2 == 1) {
            System.out.println("Слово " + word1 + " с нечетным количеством букв");
        } else {
            System.out.println("Слово " + word1 + " с четным количеством букв");
        }

        if (lettersCount2 % 2 == 1) {
            System.out.println("Слово " + word2 + " с нечетным количеством букв");
        } else {
            System.out.println("Слово " + word2 + " с четным количеством букв");
        }

        System.out.println(combineWords(word1, word2));

    }

    public static String combineWords (String word1, String word2) {
        int lengthWord1 = word1.length();
        int lengthWord2 = word2.length();
        if (lengthWord1 % 2 != 0 || lengthWord2 % 2 != 0) {
            System.out.println("Чтобы скомбинировать слова, они должны состоять из четного количества букв");
            return "";
        }
        String halfWord1 = word1.substring(0, lengthWord1 / 2);
        String halfWord2 = word2.substring(lengthWord2 / 2);
        return halfWord1 + halfWord2;
    }
}