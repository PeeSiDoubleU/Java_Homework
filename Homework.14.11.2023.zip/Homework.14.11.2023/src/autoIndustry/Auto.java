package autoIndustry;

public class Auto {
    public String carModel;
    public int maximumSpeed;
    public String carColor;
    public int dateOfIssue;
    public String carCost;

    public Auto(String carModel, int maximumSpeed, String carColor, int dateOfIssue, String carCost) {
        this.carModel = carModel;
        this.maximumSpeed = maximumSpeed;
        this.carColor = carColor;
        this.dateOfIssue = dateOfIssue;
        this.carCost = carCost;
    }

    @Override
    public String toString() {
        return "Автомобиль --- " +
                "Модель автомобиля: " + carModel +
                ", максимальная скорость: " + maximumSpeed+"km" +
                ", цвет: " + carColor +
                ", год выпуска: " + dateOfIssue +
                ", стоимость: " + carCost;
    }
}
