package math;

public class MyMath {
    private MyMath() {}
    public static int addAll(int... all) {
        int sum = 0;
        for (int i = 0; i < all.length; i++) {
            sum += all[i];
        } return sum;
    }
    public static int minusAll (int num, int... all) {
        for (int i = 0; i < all.length; i++) {
            num -= all[i];
        } return num;
    }
    public static int multAll (int... all) {
        int sum = 1;
        for (int i = 0; i < all.length; i++) {
            sum *= all[i];
        } return sum;
    }
    public static long powAll(long num, long... all) {
        for (long power : all) {
            num = customPow(num, power);
        }
        return num;
    }
    private static long customPow(long num, long power) {
        long result = 1;
        for (int i = 0; i < Math.abs(power); i++) {
            result *= num;
        }
        return (power >= 0) ? result : 1 / result;
    }
}
