import autoIndustry.Auto;
import math.MyMath;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        int [] numbers = {2, 3, 5};
        long [] numbers2 = {2, 3, 4};
        int num = 10;
        System.out.println("Сумма чисел = " + MyMath.addAll(numbers));
        System.out.println("Вычитание чисел = " + MyMath.minusAll(num,numbers));
        System.out.println("Умножение чисел = " + MyMath.multAll(numbers));
        System.out.println("Возведение в степени = " + MyMath.powAll(num, numbers2));


        Auto car1 = new Auto("Audi A-100", 180, "Black", 1991, "1500$");
        Auto car2 = new Auto("Honda Civic Sport", 280, "Blue",2023, "44000€");
        Auto car3 = new Auto("BMW M6 Gran Coupe", 300, "Matte-silver",2018, "42900€");

        Auto [] autos = {car1,car2,car3};
        
        System.out.println(Arrays.toString(autos));
    }
}
// Создайте утилитарный класс, который будет аналогом класса Math. В нём будет один приватный конструктор,
// а также только статические методы:
//addAll - сложение неограниченного числа аргументов
//minusAll – принимает исходное число и неограниченный набор аргументов, которые нужно вычесть из исходного числа
//multAll – перемножает все данные аргументы
//powAll – принимает исходное число-основание и неограниченный набор аргументов степеней.
// Нужно последовательно возвести основание во все степени.
//Используйте все методы в коде метода main.