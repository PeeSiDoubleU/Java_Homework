import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        System.out.println("Введите своё имя: ");
        String uName = scan.nextLine();
        System.out.println("Сколько вам полных лет?");
        int uAge = scan.nextInt();
        System.out.println("Какой у вас вес?");
        double uWeight = scan.nextDouble();
        System.out.printf("Уважаемый, %s! В свои %d лет Вы для нас дороги, как %s килограмм золота.", uName, uAge, uWeight);
    }
}