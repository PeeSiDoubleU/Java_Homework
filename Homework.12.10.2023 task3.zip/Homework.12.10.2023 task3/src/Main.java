import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanNumber = new Scanner(System.in);
        System.out.println("Введите первое целое число: ");
        int num1 = scanNumber.nextInt();
        System.out.println("Введите второе целое число: ");
        int num2 = scanNumber.nextInt();

        System.out.println("При сложении ваших чисел мы получаем: " + (num1 + num2));
        System.out.println("При вычитании ваших чисел мы получаем: " + (num1 - num2));
        System.out.println("При умножении ваших чисел мы получаем: " + (num1 * num2));
        System.out.println("При делении ваших чисел мы получаем: " + (num1 / num2));
    }
}