public class Main {
    public static void main(String[] args) {
        int i = 495;
        int numberOne = i / 100;
        int numberTwo = i / 10 % 10;
        int numberThree = i % 10;
        System.out.println("Число " + i + " = -> " + numberOne + ","  +  numberTwo + "," + numberThree);





    }
}