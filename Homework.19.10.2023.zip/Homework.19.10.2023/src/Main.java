import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Random ran = new Random();
        int num1 = ran.nextInt(1, 16);
        int num2 = ran.nextInt(1, 16);
        System.out.println(num1);
        System.out.println(num2);
        int dist1 = Math.abs(10 - num1);
        int dist2 = Math.abs(10 - num2);

        if (dist1 > dist2){
            System.out.println("Число " + num2 + " ближе к 10");
        } else {
            System.out.println("Число " + num1 + " ближе к 10");

        }

        }

    }