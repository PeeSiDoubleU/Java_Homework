import java.util.Scanner;

public class task3 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int elvisWasBorn = 1935;
        int elvisLived = 1977;
        System.out.println("Введи год: ");
        int userYear = scan.nextInt();
        String conclusion = userYear < elvisWasBorn? "Элвис еще не родился" :
                (userYear > elvisLived? "Элвис всегда в наших сердцах" : "Элвис жив");
        System.out.println(conclusion);
    }
}
