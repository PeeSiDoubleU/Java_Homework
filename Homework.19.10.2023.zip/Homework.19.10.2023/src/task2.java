import java.util.Random;
import java.util.Scanner;

public class task2 {
    public static void main(String[] args) {
        Random ran = new Random();
        int num1 = ran.nextInt(1, 11);
        int num2 = ran.nextInt(1, 11);
        Scanner scan = new Scanner(System.in);
        System.out.println("Сколько будет " + num1 + " умножить на " +  num2 + " ?");
        int userAnswer = scan.nextInt();
        int correctAnswer = num1 * num2;
        if (userAnswer == correctAnswer) {
            System.out.println("Вы ответили верно!");
        } else {
            System.out.println("Не верный ответ \uD83E\uDD37, правильный ответ: " + correctAnswer);
        }
    }
}
