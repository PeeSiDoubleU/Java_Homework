import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Random allRandom = new Random();
        byte b1 = (byte) allRandom.nextInt(-127 ,127);
        short s1 = (short) allRandom.nextInt(25555);
        int i1 = allRandom.nextInt(105005);
        long l1 = allRandom.nextLong(9545000);
        float f1 = allRandom.nextFloat(13.3F, 23.3F);
        double d1 = allRandom.nextDouble(66.6, 155.55);
        boolean bool1 = allRandom.nextBoolean();
        char c1 = (char) allRandom.nextInt(100, 500);

        System.out.println(b1);
        System.out.println(s1);
        System.out.println(i1);
        System.out.println(l1);
        System.out.println(f1);
        System.out.println(d1);
        System.out.println(bool1);
        System.out.println(c1);

// Задание #1 пункт 2
        int i2 = allRandom.nextInt(450);
        String str = i2 + "";
        System.out.println(str);

    }
}