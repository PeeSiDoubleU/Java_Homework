public class Main {
    public static void main(String[] args) {
        char g = 'G';
        int i = 89;
        byte b = 4;
        short s = 56;
        float f = 4.7333436F;
        double d = 4.355453532;
        long l = 12121;
        
        System.out.println(g);
        System.out.println(i);
        System.out.println(b);
        System.out.println(s);
        System.out.println(f);
        System.out.println(d);
        System.out.println(l);
    }
}