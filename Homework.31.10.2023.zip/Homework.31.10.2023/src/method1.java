import java.util.Random;

public class method1 {
    public static void main(String[] args) {
        Random rand = new Random();
        int n1 = rand.nextInt(2, 10);
        int n2 = rand.nextInt(2, 10);
        int n3 = rand.nextInt(2, 10);
        int n4 = rand.nextInt(2, 10);
        System.out.println(n1);
        System.out.println(n2);
        System.out.println(n3);
        System.out.println(n4);
        System.out.println(getMultiplication(n1, n2));
        System.out.println(getMultiplication(n1, n2, n3));
        System.out.println(getMultiplication(n1, n2, n3, n4));
    }
    private static int getMultiplication (int num1, int num2) {
        int result = num1 * num2;
        return result;
    }

    private static int getMultiplication (int num1, int num2, int num3) {
        int result = getMultiplication(num1, num2) * num3;
        return result;
    }
    private static int getMultiplication (int num1, int num2, int num3, int num4) {
        int result = getMultiplication(num1, num2, num3) * num4;
        return result;
    }

}