import java.util.Scanner;

public class method2 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Введите число:");
        int userNum = scan.nextInt();
        System.out.println(factorial(userNum));
    }

    private static int factorial (int num) {
        int result = 1;
        for (int i = 1; i <= num; i++) {
            result *= i;
        }
        return result;
    }
}
