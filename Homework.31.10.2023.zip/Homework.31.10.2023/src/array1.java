import java.util.Arrays;
import java.util.Random;

public class array1 {
    public static void main(String[] args) {
        Random rand = new Random();
        int [] numbers = new int[8]; // пустой массив
        System.out.println(Arrays.toString(numbers));

        for (int i = 0; i < numbers.length; i++) {
            numbers [i] = rand.nextInt(1, 50); // заполняем массив
        }
        System.out.println(Arrays.toString(numbers)); // заполненный массив

        for (int i = 0; i < numbers.length; i++) { // заменяем на нули числа с нечестным индексом.
            if (i % 2 == 1) {
                numbers[i] = 0;
            }
        }
        System.out.println(Arrays.toString(numbers));

        Arrays.sort(numbers); // сортируем массив

        System.out.println(Arrays.toString(numbers)); // отсортированный массив
    }
}
