import java.util.Arrays;

public class array2 {
    public static void main(String[] args) {
        String [] words = {"Cat", "Behemoth", "Bird", "Snake", "Lion"};
        System.out.println(Arrays.toString(words));
        String shortWord = null;
        String longWord = null;

        for (String str: words) {
            if (shortWord == null || str.length() < shortWord.length()) {
                shortWord = str;
            }
            if (longWord == null || str.length() > longWord.length()) {
                longWord = str;
            }
        }
        System.out.println(shortWord);
        System.out.println(longWord);
    }
}
