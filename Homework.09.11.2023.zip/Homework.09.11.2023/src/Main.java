import auto.Auto;
import auto.Factory;
import auto.TypeOfCarDrive;


public class Main {
    public static void main(String[] args) {
        Factory factory = new Factory();
        Auto myAuto = factory.createAuto("Honda", 180, "White", TypeOfCarDrive.FRONT_WHEEL_DRIVE);
        myAuto.carModel = "Mercedes Benz";
        // myAuto.maximumSpeed = "" /не могу присвоить т.к. поле без модификатора доступа.
        myAuto.setMaximumSpeed(233); // добавит сеттер и геттер чтобы можно было присвоить.
        myAuto.setCarColor("Blue");
        myAuto.setDriveType(TypeOfCarDrive.ALL_WHEEL_DRIVE);

        System.out.println("Марка авто: " + myAuto.carModel);
        System.out.println("Максимальная скорость: " + myAuto.getMaximumSpeed());
        System.out.println("Цвет: " + myAuto.getCarColor());
        System.out.println("Привод: " + myAuto.getDriveType());

    }
}