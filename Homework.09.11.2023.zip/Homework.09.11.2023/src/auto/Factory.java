package auto;

public class Factory {
    public Auto createAuto (String carModel, int maximumSpeed, String carColor, TypeOfCarDrive driveType){
        Auto firstAuto = new Auto("BMW", 277, "Quartz", TypeOfCarDrive.ALL_WHEEL_DRIVE);
        firstAuto.setCarColor("Black");
        firstAuto.setDriveType(TypeOfCarDrive.REAR_WHEEL_DRIVE);
        return firstAuto;
    }
}
