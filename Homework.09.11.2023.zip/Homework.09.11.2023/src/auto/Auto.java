package auto;

public class Auto {

    public String carModel;
    int maximumSpeed;
    private String carColor;
    private TypeOfCarDrive driveType;

    public Auto(String carModel, int maximumSpeed, String carColor, TypeOfCarDrive driveType) {
        this.carModel = carModel;
        this.maximumSpeed = maximumSpeed;
        this.carColor = carColor;
        this.driveType = driveType;
    }

    public int getMaximumSpeed() {
        return maximumSpeed;
    }

    public void setMaximumSpeed(int maximumSpeed) {
        this.maximumSpeed = maximumSpeed;
    }

    public String getCarColor() {
        return carColor;
    }

    public void setCarColor(String carColor) {
        this.carColor = carColor;
    }

    public TypeOfCarDrive getDriveType() {
        return driveType;
    }

    public void setDriveType(TypeOfCarDrive driveType) {
        this.driveType = driveType;
    }

}
