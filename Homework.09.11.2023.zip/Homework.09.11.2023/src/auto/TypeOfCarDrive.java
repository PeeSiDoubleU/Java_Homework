package auto;

public enum TypeOfCarDrive {
    FRONT_WHEEL_DRIVE,
    REAR_WHEEL_DRIVE,
    FOUR_WHEEL_DRIVE,
    ALL_WHEEL_DRIVE,

}
