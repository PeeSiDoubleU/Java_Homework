public class task3 {
    public static void main(String[] args) {
        boolean isYearFinished = true;
        boolean isGoodWeather = true;
        boolean isBadWeather = false;
        boolean hasBoutRaincoats = true;
        boolean isJimFree = true;
        boolean hasKateComeBack = false;
        boolean isEverythinkWillTakePlace = (isYearFinished && isGoodWeather) && (isBadWeather || hasBoutRaincoats)
                && (isJimFree ^ hasKateComeBack);
        System.out.println(isEverythinkWillTakePlace);
    }
}
