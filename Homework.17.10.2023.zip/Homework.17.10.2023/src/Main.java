public class Main {
    public static void main(String[] args) {
        int meters = (int) 5900.0;
        double km = meters / 1000.0;
        double miles = meters / 1609.0;
        int feet = (int) (meters * 3.281);
        int arshin = (int) (meters / 1.406);


        System.out.println("Дано: " + meters + " метров");
        System.out.println("Конвертация в километры " + km);
        System.out.println("Конвертация в мили " + miles);
        System.out.println("Конвертация в футы " + feet);
        System.out.println("Конвертация в аршины " + arshin);
    }
}