import java.util.Scanner;

public class task2 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Введите сумму товара: ");
        double price = scan.nextDouble();
        System.out.println("Какую сумму вы вносите: ");
        double sum = scan.nextDouble();
        double refund = sum - price;
        int euro = (int) ((int) sum - price);
        double cent1 = refund - euro;
        double cent2 = cent1 * 100;
        int cent3 = (int) (cent2);
        System.out.println("Ваша сдача: " + euro + " Euro " + cent3 + " cent");


    }
}
