import java.util.Scanner;

public class task4 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Введите целое число: ");
        int num = scan.nextInt();
        int num1 = num >>1;
        System.out.println(num1);
    }
}
