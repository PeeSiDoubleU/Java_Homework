import java.util.Arrays;

public class task2 {
    public static void main(String[] args) {
        int rows = 3;
        int cols = 11;
        char [][] alphabet = new char [rows][cols];
        System.out.println(Arrays.deepToString(alphabet));

        char fillChar = 'А';
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                if (i == 0 && j == 6) {
                    alphabet[i][j] = 'Ё';
                } else {
                    alphabet[i][j] = fillChar;
                    fillChar++;
                }
            }
        }
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                System.out.println(alphabet[i][j] + " ");
            }
        }
        System.out.println(Arrays.deepToString(alphabet));

    }
}