import java.time.LocalDate;
import java.util.Arrays;

public class task1 {
    public static void main(String[] args) {
        LocalDate [] dates = {
                LocalDate.of(2001, 7, 19),
                LocalDate.of(2003, 12, 23),
                LocalDate.of(1984, 4, 24),
                LocalDate.of(1999, 3, 14),
                LocalDate.of(2000, 2, 5),
                LocalDate.of(2005, 5, 17),
                LocalDate.of(1942, 8, 11),
                LocalDate.of(1877, 11, 29),
        };

        System.out.println(Arrays.toString(dates));
        dates = bubbleSortYear(dates);
        System.out.println(Arrays.toString(dates));
        dates = bubbleSortMonth(dates);
        System.out.println(Arrays.toString(dates));

    }

    public static LocalDate [] bubbleSortYear (LocalDate [] dates) {
        int n = dates.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (dates[j].compareTo(dates[j + 1]) > 0) {
                    LocalDate temp = dates[j];
                    dates [j] = dates [j+ 1];
                    dates [j + 1] = temp;
                }
            }
        }
        return dates;
    }


    public static LocalDate [] bubbleSortMonth (LocalDate [] dates) {
        int n = dates.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (dates[j].getMonthValue() > dates[j + 1].getMonthValue()) {
                    LocalDate temp = dates[j];
                    dates [j] = dates [j+ 1];
                    dates [j + 1] = temp;
                }
            }
        }
        return dates;
    }

}