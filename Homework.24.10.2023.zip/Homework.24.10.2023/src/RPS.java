import games.Rpsgame;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;


public class RPS {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        Random ran = new Random();


        System.out.println("Введите один из вариантов: " + Arrays.toString(Rpsgame.values()));
        String userInput = scan.nextLine();
        Rpsgame input = Rpsgame.valueOf(userInput.toUpperCase());
        Rpsgame userAnswer = switch (input) {
            case ROCK -> Rpsgame.ROCK;
            case PAPER -> Rpsgame.PAPER;
            case SCISSORS -> Rpsgame.SCISSORS;
        };
        System.out.println("Ваш выбор: " + input);
        int compRandom = ran.nextInt(Rpsgame.values().length);
        Rpsgame compOutput = Rpsgame.values()[compRandom];
        System.out.println("Компьютер выбрал: " + compOutput);
        if (userAnswer.equals(compOutput)) {
            System.out.println("У вас ничья");
        } else {
            if (userAnswer == Rpsgame.ROCK && compOutput == Rpsgame.SCISSORS
            || userAnswer == Rpsgame.PAPER && compOutput == Rpsgame.ROCK
            || userAnswer == Rpsgame.SCISSORS && compOutput == Rpsgame.PAPER){
                System.out.println("Вы выиграли!");
            } else {
                System.out.println("Вы проиграли");
            }
        }
    }
}
