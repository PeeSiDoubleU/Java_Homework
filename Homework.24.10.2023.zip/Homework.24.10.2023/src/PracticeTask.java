import months.Month;
import java.util.Scanner;

public class PracticeTask {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Введите месяц: ");
        String userInput = scan.nextLine();
        Month input = Month.valueOf(userInput.toUpperCase());
        Month answer = switch (input) {
            case ЯНВАРЬ -> Month.ЯНВАРЬ;
            case ФЕВРАЛЬ -> Month.ФЕВРАЛЬ;
            case МАРТ -> Month.МАРТ;
            case АПРЕЛЬ -> Month.АПРЕЛЬ;
            case МАЙ -> Month.МАЙ;
            case ИЮНЬ -> Month.ИЮНЬ;
            case ИЮЛЬ -> Month.ИЮЛЬ;
            case АВГУСТ -> Month.АВГУСТ;
            case СЕНТЯБРЬ -> Month.СЕНТЯБРЬ;
            case ОКТЯБРЬ -> Month.ОКТЯБРЬ;
            case НОЯБРЬ -> Month.НОЯБРЬ;
            case ДЕКАБРЬ -> Month.ДЕКАБРЬ;
        };

        String answer2 = switch (answer){
            case ЯНВАРЬ -> "зима";
            case ФЕВРАЛЬ -> "зима";
            case МАРТ -> "весна";
            case АПРЕЛЬ -> "весна";
            case МАЙ -> "весна";
            case ИЮНЬ -> "лето";
            case ИЮЛЬ -> "лето";
            case АВГУСТ -> "лето";
            case СЕНТЯБРЬ -> "осень";
            case ОКТЯБРЬ -> "осень";
            case НОЯБРЬ -> "осень";
            case ДЕКАБРЬ -> "зима";
        };
        System.out.println(answer + " это: " + answer2);

    }
}
