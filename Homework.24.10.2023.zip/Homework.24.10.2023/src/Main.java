import anniversaries.Wedding;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Сколько лет вы состоите в браке?  ");
        int userNum = scan.nextInt();
        Wedding userWed = switch (userNum) {
            case 0 -> Wedding.СИТЦЕВАЯ;
            case 1 -> Wedding.БУМАЖНАЯ;
            case 2 -> Wedding.КОЖАНАЯ;
            case 3 -> Wedding.ЛЬНЯНАЯ;
            case 4 -> Wedding.ДЕВЕРЕВЯННАЯ;
            case 5 -> Wedding.ЧУГУННАЯ;
            case 6 -> Wedding.МЕДНАЯ;
            case 7 -> Wedding.ЖЕСТЯНАЯ;
            case 8 -> Wedding.ФАЯНСОВАЯ;
            case 9 -> Wedding.ОЛОВЯННАЯ;
            case 10 -> Wedding.СТАЛЬНАЯ;
            case 11 -> Wedding.НИКЕЛЕВАЯ;
            case 12 -> Wedding.КРУЖЕВНАЯ;
            case 13 -> Wedding.АГАТОВАЯ;
            case 14 -> Wedding.ХРУСТАЛЬНАЯ;
            default -> throw new RuntimeException("К сожалению мы не можем посчитать вашу дату");
        };

        System.out.println("Следующая годовщина вашей свадьбы будет " + userWed + ". Поздраляем!");
    }
}
// Пользователь вводит, сколько лет он состоит в браке.
// Программа должна вывести, какая годовщина свадьбы будет у пользователя следующей
// (бумажная, ситцевая, чугунная, серебряная и.д.). Не обязательно указывать все годовщины, достаточно 10-15.