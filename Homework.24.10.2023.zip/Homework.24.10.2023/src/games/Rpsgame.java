package games;

public enum Rpsgame {
    ROCK,
    PAPER,
    SCISSORS
}
