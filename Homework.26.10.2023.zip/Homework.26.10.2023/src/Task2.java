import java.util.Scanner;

public class Task2 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
    do {
        System.out.println("Введите число: ");
        int userNum = scan.nextInt();
        System.out.println("Введите второе число: ");
        int userNum2 = scan.nextInt();
        int sum = 0;
        int max = Math.max(userNum, userNum2);
        int min = Math.min(userNum, userNum2);
        for (int i = min; i <= max; i += 1) {
            if (i % 2 != 0) {
                sum = sum + i;
            }
        }
        System.out.println(sum);
        System.out.println("Для выхода введите quit");
        scan.nextLine();
    } while (!"quit".equalsIgnoreCase(scan.nextLine()));

    }
}