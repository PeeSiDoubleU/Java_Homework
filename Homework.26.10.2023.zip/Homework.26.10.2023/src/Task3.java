import daysOfTheWeek.Days;
import java.util.Arrays;
import java.util.Scanner;

public class Task3 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Введите какой сегодня день недели: " + Arrays.toString(Days.values()));
        String userInput = scan.nextLine();
        userInput = userInput.toUpperCase();
        for (Days d : Days.values()) {
            if (userInput.equals(d.toString())) {
                continue;
            }
            System.out.println(d);
        }
    }
}