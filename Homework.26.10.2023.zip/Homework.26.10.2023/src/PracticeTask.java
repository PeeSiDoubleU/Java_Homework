
import java.util.Random;
import java.util.Scanner;

public class PracticeTask {
    public static void main(String[] args) {
        Random rand = new Random();
        Scanner scan = new Scanner(System.in);
        int elevatorFloor = rand.nextInt(1, 36);
        System.out.println("Лифт находится на " + elevatorFloor);
        System.out.println("На каком вы этаже?");
        int userFloor = scan.nextInt();
        int sign = elevatorFloor > userFloor? -1 : 1;
        boolean isCorrectFloor = userFloor == elevatorFloor;
        int currentFloor = elevatorFloor;
        while (!isCorrectFloor) {
            System.out.println(currentFloor);
            isCorrectFloor = currentFloor == userFloor;
            currentFloor += sign;
        }
    }
}

