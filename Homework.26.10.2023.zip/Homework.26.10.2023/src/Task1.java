import java.util.Random;

public class Task1 {
    public static void main(String[] args) {
        Random rand = new Random();
        int target = 10000;
        int sum = 0;
        while (sum <= target){
            int banknote = rand.nextInt(1,5);
            int randBanknote = switch (banknote){
                case 1 -> 50;
                case 2 -> 100;
                case 3 -> 200;
                default -> 500;
            };
            sum = sum + randBanknote;
        }
        System.out.println(sum);
        System.out.println("Вы собрали деньги на компьютер");
    }
}
/*
Напиши программу, которая моделирует ситуацию.
Ты попросил(а) друзей скинуться на подарок на твой День Рождения.
Каждый друг случайным образом может подарить тебе одну купюру номиналом 50, 100, 200 или 500 долларов.
Твоя цель - новенький игровой компьютер, который стоит 10 000 долларов.
Как только друзья подарят тебе нужную сумму (или даже чуть больше),
останавливай сбор подарков и веди всех выпить за твоё здоровье в лучший бар города!
 */